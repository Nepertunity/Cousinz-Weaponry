scoreboard objectives add nep.dash dummy
scoreboard objectives add nep.timer dummy
scoreboard objectives add nep.health health
scoreboard objectives add nep.dash_timer dummy
scoreboard objectives add tf_rc dummy
scoreboard objectives add nep.particles dummy
scoreboard objectives add nep.math dummy
scoreboard objectives add nep.bool dummy
scoreboard objectives add motion_x dummy
scoreboard objectives add motion_y dummy
scoreboard objectives add motion_z dummy
scoreboard objectives add nep.distance dummy
scoreboard objectives add nep.motion dummy
scoreboard objectives add nep.temp dummy
scoreboard objectives add nep.diamond_spear minecraft.used:minecraft.diamond_spear
scoreboard objectives add nep.wooden_spear minecraft.used:minecraft.wooden_spear
scoreboard objectives add nep.copper_spear minecraft.used:minecraft.copper_spear
scoreboard objectives add nep.iron_spear minecraft.used:minecraft.iron_spear
scoreboard objectives add nep.stone_spear minecraft.used:minecraft.stone_spear
scoreboard objectives add nep.golden_spear minecraft.used:minecraft.golden_spear
scoreboard objectives add nep.netherite_spear minecraft.used:minecraft.netherite_spear
scoreboard objectives add nep.fishing_rod minecraft.used:minecraft.fishing_rod
scoreboard objectives add nep.spyglass minecraft.used:minecraft.spyglass
scoreboard objectives add nep.bow minecraft.used:minecraft.bow
scoreboard objectives add nep.crossbow minecraft.used:minecraft.crossbow
function nep:abilities/load_all
function nep:weapons/load_all
function nep:battlemonk/load
function nep:general_load
