function nep:weapons/right/right
advancement revoke @s only nep:right_click
