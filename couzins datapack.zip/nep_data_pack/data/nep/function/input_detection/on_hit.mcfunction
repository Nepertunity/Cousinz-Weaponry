function nep:weapons/hit/hit
advancement revoke @s only nep:on_hit
