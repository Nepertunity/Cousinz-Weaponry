execute unless predicate nep:is_on_ground run function nep:input_detection/jump/nested_execute_0
