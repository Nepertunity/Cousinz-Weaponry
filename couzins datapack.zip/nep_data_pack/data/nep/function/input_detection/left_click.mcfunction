execute as @s[nbt={SelectedItem: {id: "minecraft:iron_sword", count: 1}}] at @s run function nep:battlemonk/left
function nep:weapons/left/left
