advancement revoke @s only nep:input_jump_2
