execute as @a run function nep:input_detection/dash/dash_tick/nested_execute_1
