execute if score @s nep_dash matches 1.. run scoreboard players add @s nep_dash_timer 1
execute if score @s nep_dash_timer matches 4.. run function nep:input_detection/dash/dash_tick/nested_execute_0
