scoreboard players reset @s nep_dash_timer
scoreboard players reset @s nep_dash
