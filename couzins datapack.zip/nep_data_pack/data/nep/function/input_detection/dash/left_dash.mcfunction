scoreboard players add @s nep_dash 1
execute if score @s nep_dash matches 2.. run function nep:input_detection/dash/left_dash/nested_execute_0
