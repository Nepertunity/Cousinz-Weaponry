advancement revoke @s only nep:input_left
