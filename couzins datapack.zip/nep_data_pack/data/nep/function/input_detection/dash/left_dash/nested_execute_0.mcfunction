scoreboard players set $strength player_motion.api.launch 8000
execute at @s rotated ~90 ~ run function player_motion:api/launch_looking
