function nep:input_detection/dash/left_dash
advancement revoke @s only nep:input_left_2
