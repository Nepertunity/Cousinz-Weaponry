function nep:weapons/swap/swap
