function nep:abilities/tick_all
function nep:weapons/tick_all
function nep:general_tick
function nep:input_detection/dash/dash_tick
function nep:battlemonk/tick
scoreboard players reset @a sneaking
advancement revoke @a only nep:shoot_crossbow
scoreboard players reset @a nep.fishing_rod
scoreboard players reset @a nep.bow
scoreboard players reset @a nep.crossbow
execute as @a store result score @s nep.motion run data get entity @s Motion[1] 10000
