tag @s add shooter
playsound minecraft:entity.copper_golem.spawn ambient @a ~ ~ ~ 1 0.9
summon marker ^ ^ ^ {Tags: ["nep.arcane_bow.shootersp", "nep.arcane_bow.shooter_r_1", "nep.arcane_bow.shooter_r"]}
summon marker ^ ^ ^ {Tags: ["nep.arcane_bow.shootersp", "nep.arcane_bow.shooter_r_2", "nep.arcane_bow.shooter_r"]}
summon marker ^ ^ ^ {Tags: ["nep.arcane_bow.shootersp", "nep.arcane_bow.shooter_r_3", "nep.arcane_bow.shooter_r"]}
summon marker ^ ^ ^ {Tags: ["nep.arcane_bow.shootersp", "nep.arcane_bow.shooter_r_4", "nep.arcane_bow.shooter_r"]}
summon marker ^ ^ ^ {Tags: ["nep.arcane_bow.shootersp", "nep.arcane_bow.shooter_r_5", "nep.arcane_bow.shooter_r"]}
summon marker ^ ^ ^ {Tags: ["nep.arcane_bow.shootersp", "nep.arcane_bow.shooter_r_6", "nep.arcane_bow.shooter_r"]}
summon marker ^ ^ ^ {Tags: ["nep.arcane_bow.shootersp", "nep.arcane_bow.shooter_r_7", "nep.arcane_bow.shooter_r"]}
execute store result score @e[tag=nep.arcane_bow.shootersp] lib.ID run scoreboard players get @s lib.ID
execute as @e[tag=nep.arcane_bow.shootersp] at @s store result entity @s Rotation[0] float 0.01 run data get entity @p[tag=shooter] Rotation[0] 100
execute as @e[tag=nep.arcane_bow.shootersp] at @s store result entity @s Rotation[1] float 0.01 run data get entity @p[tag=shooter] Rotation[1] 100
execute as @e[tag=nep.arcane_bow.shootersp] at @s run tp @s ^ ^ ^ ~-30 ~
playsound minecraft:entity.breeze.jump ambient @a
execute store result score @n[tag=nep.arcane_bow.shootersp] lib.ID run scoreboard players get @s lib.ID
execute as @e[tag=nep.arcane_bow.shooter_r_1] at @s run tp @s ^ ^ ^ ~0 ~
execute as @e[tag=nep.arcane_bow.shooter_r_2] at @s run tp @s ^ ^ ^ ~10 ~
execute as @e[tag=nep.arcane_bow.shooter_r_3] at @s run tp @s ^ ^ ^ ~20 ~
execute as @e[tag=nep.arcane_bow.shooter_r_4] at @s run tp @s ^ ^ ^ ~30 ~
execute as @e[tag=nep.arcane_bow.shooter_r_5] at @s run tp @s ^ ^ ^ ~40 ~
execute as @e[tag=nep.arcane_bow.shooter_r_6] at @s run tp @s ^ ^ ^ ~50 ~
execute as @e[tag=nep.arcane_bow.shooter_r_7] at @s run tp @s ^ ^ ^ ~60 ~
tag @e[tag=nep.arcane_bow.shootersp] remove nep.arcane_bow.shootersp
tag @s remove shooter
scoreboard players reset @s nep.arcane_bow.volley
