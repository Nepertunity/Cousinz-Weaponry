particle trial_omen ^ ^ ^10.499999999999979
execute positioned ^ ^ ^10.599999999999978 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_112
execute positioned ^ ^ ^10.699999999999978 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_113
execute positioned ^ ^ ^10.799999999999978 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_114
execute positioned ^ ^ ^10.899999999999977 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_115
execute positioned ^ ^ ^10.999999999999977 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_116
execute positioned ^ ^ ^11.099999999999977 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_117
execute positioned ^ ^ ^11.199999999999976 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_118
execute positioned ^ ^ ^11.299999999999976 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_119
execute positioned ^ ^ ^11.399999999999975 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_120
execute positioned ^ ^ ^11.499999999999975 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_121
execute positioned ^ ^ ^11.599999999999975 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_122
execute positioned ^ ^ ^11.699999999999974 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_123
execute positioned ^ ^ ^11.799999999999974 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_124
execute positioned ^ ^ ^11.899999999999974 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_125
execute positioned ^ ^ ^11.999999999999973 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_126
