execute positioned ^0.0374769735668358 ^ ^-0.1964573145807269 as @e[tag=!raycasting, dx=0] positioned ~-0.7 ~-0.7 ~-0.7 if entity @s[dx=0] positioned ~0.7 ~0.7 ~0.7 run function nep:weapons/weapons/cousins/connroc/beam_collide
execute positioned ^-0.0374769735668358 ^ ^0.1964573145807269 as @e[tag=!raycasting, dx=0] positioned ~-0.7 ~-0.7 ~-0.7 if entity @s[dx=0] positioned ~0.7 ~0.7 ~0.7 run function nep:weapons/weapons/cousins/connroc/beam_collide
particle minecraft:ominous_spawning ^0.0374769735668358 ^ ^-0.1964573145807269
particle minecraft:ominous_spawning ^-0.0374769735668358 ^ ^0.1964573145807269
execute unless block ~ ~ ~ #nep:raycast_pass run scoreboard players set rayHit nep.bool 1
