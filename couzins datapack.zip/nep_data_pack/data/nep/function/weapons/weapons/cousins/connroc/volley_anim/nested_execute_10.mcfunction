particle trial_omen ^ ^ ^14.999999999999963
execute unless block ^ ^ ^15.099999999999962 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^15.099999999999962 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^15.099999999999962 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^15.199999999999962 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^15.199999999999962 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^15.199999999999962 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^15.299999999999962 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^15.299999999999962 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^15.299999999999962 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^15.399999999999961 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^15.399999999999961 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^15.399999999999961 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^15.499999999999961 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^15.499999999999961 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^15.499999999999961 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^15.59999999999996 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^15.59999999999996 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^15.59999999999996 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^15.69999999999996 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^15.69999999999996 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^15.69999999999996 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^15.79999999999996 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^15.79999999999996 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^15.79999999999996 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^15.89999999999996 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^15.89999999999996 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^15.89999999999996 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^15.99999999999996 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^15.99999999999996 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^15.99999999999996 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^16.09999999999996 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^16.09999999999996 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^16.09999999999996 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^16.19999999999996 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^16.19999999999996 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^16.19999999999996 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^16.29999999999996 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^16.29999999999996 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^16.29999999999996 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^16.399999999999963 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^16.399999999999963 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^16.399999999999963 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^16.499999999999964 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^16.499999999999964 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^16.499999999999964 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
