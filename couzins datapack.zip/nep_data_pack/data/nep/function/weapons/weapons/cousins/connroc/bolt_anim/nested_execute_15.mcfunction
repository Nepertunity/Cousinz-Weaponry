particle trial_omen ^ ^ ^
execute positioned ^ ^ ^0.1 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_0
execute positioned ^ ^ ^0.2 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_1
execute positioned ^ ^ ^0.30000000000000004 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_2
execute positioned ^ ^ ^0.4 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_3
execute positioned ^ ^ ^0.5 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_4
execute positioned ^ ^ ^0.6 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_5
execute positioned ^ ^ ^0.7 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_6
execute positioned ^ ^ ^0.7999999999999999 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_7
execute positioned ^ ^ ^0.8999999999999999 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_8
execute positioned ^ ^ ^0.9999999999999999 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_9
execute positioned ^ ^ ^1.0999999999999999 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_10
execute positioned ^ ^ ^1.2 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_11
execute positioned ^ ^ ^1.3 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_12
execute positioned ^ ^ ^1.4000000000000001 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_13
execute positioned ^ ^ ^1.5000000000000002 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_14
