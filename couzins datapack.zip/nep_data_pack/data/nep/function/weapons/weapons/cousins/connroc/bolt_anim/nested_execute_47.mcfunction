particle trial_omen ^ ^ ^3.0000000000000013
execute positioned ^ ^ ^3.1000000000000014 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_32
execute positioned ^ ^ ^3.2000000000000015 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_33
execute positioned ^ ^ ^3.3000000000000016 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_34
execute positioned ^ ^ ^3.4000000000000017 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_35
execute positioned ^ ^ ^3.5000000000000018 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_36
execute positioned ^ ^ ^3.600000000000002 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_37
execute positioned ^ ^ ^3.700000000000002 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_38
execute positioned ^ ^ ^3.800000000000002 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_39
execute positioned ^ ^ ^3.900000000000002 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_40
execute positioned ^ ^ ^4.000000000000002 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_41
execute positioned ^ ^ ^4.100000000000001 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_42
execute positioned ^ ^ ^4.200000000000001 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_43
execute positioned ^ ^ ^4.300000000000001 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_44
execute positioned ^ ^ ^4.4 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_45
execute positioned ^ ^ ^4.5 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_46
