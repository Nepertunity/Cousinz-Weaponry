particle trial_omen ^ ^ ^1.5000000000000002
execute unless block ^ ^ ^1.6000000000000003 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^1.6000000000000003 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^1.6000000000000003 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^1.7000000000000004 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^1.7000000000000004 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^1.7000000000000004 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^1.8000000000000005 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^1.8000000000000005 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^1.8000000000000005 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^1.9000000000000006 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^1.9000000000000006 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^1.9000000000000006 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^2.0000000000000004 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^2.0000000000000004 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^2.0000000000000004 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^2.1000000000000005 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^2.1000000000000005 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^2.1000000000000005 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^2.2000000000000006 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^2.2000000000000006 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^2.2000000000000006 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^2.3000000000000007 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^2.3000000000000007 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^2.3000000000000007 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^2.400000000000001 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^2.400000000000001 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^2.400000000000001 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^2.500000000000001 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^2.500000000000001 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^2.500000000000001 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^2.600000000000001 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^2.600000000000001 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^2.600000000000001 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^2.700000000000001 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^2.700000000000001 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^2.700000000000001 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^2.800000000000001 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^2.800000000000001 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^2.800000000000001 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^2.9000000000000012 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^2.9000000000000012 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^2.9000000000000012 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^3.0000000000000013 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^3.0000000000000013 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^3.0000000000000013 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
