particle trial_omen ^ ^ ^19.500000000000007
execute positioned ^ ^ ^19.60000000000001 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_208
execute positioned ^ ^ ^19.70000000000001 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_209
execute positioned ^ ^ ^19.80000000000001 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_210
execute positioned ^ ^ ^19.900000000000013 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_211
execute positioned ^ ^ ^20.000000000000014 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_212
execute positioned ^ ^ ^20.100000000000016 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_213
execute positioned ^ ^ ^20.200000000000017 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_214
execute positioned ^ ^ ^20.30000000000002 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_215
execute positioned ^ ^ ^20.40000000000002 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_216
execute positioned ^ ^ ^20.50000000000002 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_217
execute positioned ^ ^ ^20.600000000000023 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_218
execute positioned ^ ^ ^20.700000000000024 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_219
execute positioned ^ ^ ^20.800000000000026 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_220
execute positioned ^ ^ ^20.900000000000027 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_221
execute positioned ^ ^ ^21.00000000000003 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_222
