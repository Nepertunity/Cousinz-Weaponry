particle minecraft:ominous_spawning ~ ~ ~ 0 0 0 0.05 1
execute as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ~ ~ ~ #nep:raycast_pass run scoreboard players set @s nep.bool 1
