particle trial_omen ^ ^ ^16.499999999999964
execute unless block ^ ^ ^16.599999999999966 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^16.599999999999966 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^16.599999999999966 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^16.699999999999967 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^16.699999999999967 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^16.699999999999967 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^16.79999999999997 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^16.79999999999997 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^16.79999999999997 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^16.89999999999997 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^16.89999999999997 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^16.89999999999997 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^16.99999999999997 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^16.99999999999997 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^16.99999999999997 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^17.099999999999973 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^17.099999999999973 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^17.099999999999973 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^17.199999999999974 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^17.199999999999974 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^17.199999999999974 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^17.299999999999976 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^17.299999999999976 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^17.299999999999976 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^17.399999999999977 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^17.399999999999977 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^17.399999999999977 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^17.49999999999998 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^17.49999999999998 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^17.49999999999998 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^17.59999999999998 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^17.59999999999998 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^17.59999999999998 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^17.69999999999998 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^17.69999999999998 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^17.69999999999998 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^17.799999999999983 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^17.799999999999983 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^17.799999999999983 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^17.899999999999984 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^17.899999999999984 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^17.899999999999984 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^17.999999999999986 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^17.999999999999986 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^17.999999999999986 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
