particle trial_omen ^ ^ ^1.5000000000000002
execute positioned ^ ^ ^1.6000000000000003 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_16
execute positioned ^ ^ ^1.7000000000000004 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_17
execute positioned ^ ^ ^1.8000000000000005 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_18
execute positioned ^ ^ ^1.9000000000000006 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_19
execute positioned ^ ^ ^2.0000000000000004 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_20
execute positioned ^ ^ ^2.1000000000000005 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_21
execute positioned ^ ^ ^2.2000000000000006 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_22
execute positioned ^ ^ ^2.3000000000000007 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_23
execute positioned ^ ^ ^2.400000000000001 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_24
execute positioned ^ ^ ^2.500000000000001 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_25
execute positioned ^ ^ ^2.600000000000001 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_26
execute positioned ^ ^ ^2.700000000000001 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_27
execute positioned ^ ^ ^2.800000000000001 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_28
execute positioned ^ ^ ^2.9000000000000012 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_29
execute positioned ^ ^ ^3.0000000000000013 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_30
