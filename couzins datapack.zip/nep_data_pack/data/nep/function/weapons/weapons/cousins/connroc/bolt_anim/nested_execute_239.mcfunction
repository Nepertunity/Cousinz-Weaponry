particle trial_omen ^ ^ ^21.00000000000003
execute positioned ^ ^ ^21.10000000000003 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_224
execute positioned ^ ^ ^21.20000000000003 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_225
execute positioned ^ ^ ^21.300000000000033 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_226
execute positioned ^ ^ ^21.400000000000034 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_227
execute positioned ^ ^ ^21.500000000000036 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_228
execute positioned ^ ^ ^21.600000000000037 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_229
execute positioned ^ ^ ^21.70000000000004 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_230
execute positioned ^ ^ ^21.80000000000004 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_231
execute positioned ^ ^ ^21.90000000000004 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_232
execute positioned ^ ^ ^22.000000000000043 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_233
execute positioned ^ ^ ^22.100000000000044 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_234
execute positioned ^ ^ ^22.200000000000045 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_235
execute positioned ^ ^ ^22.300000000000047 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_236
execute positioned ^ ^ ^22.40000000000005 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_237
execute positioned ^ ^ ^22.50000000000005 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_238
