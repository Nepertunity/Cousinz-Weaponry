particle trial_omen ^ ^ ^17.999999999999986
execute positioned ^ ^ ^18.099999999999987 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_192
execute positioned ^ ^ ^18.19999999999999 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_193
execute positioned ^ ^ ^18.29999999999999 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_194
execute positioned ^ ^ ^18.39999999999999 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_195
execute positioned ^ ^ ^18.499999999999993 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_196
execute positioned ^ ^ ^18.599999999999994 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_197
execute positioned ^ ^ ^18.699999999999996 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_198
execute positioned ^ ^ ^18.799999999999997 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_199
execute positioned ^ ^ ^18.9 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_200
execute positioned ^ ^ ^19.0 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_201
execute positioned ^ ^ ^19.1 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_202
execute positioned ^ ^ ^19.200000000000003 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_203
execute positioned ^ ^ ^19.300000000000004 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_204
execute positioned ^ ^ ^19.400000000000006 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_205
execute positioned ^ ^ ^19.500000000000007 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_206
