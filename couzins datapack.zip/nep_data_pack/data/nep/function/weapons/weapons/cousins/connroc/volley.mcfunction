execute at @s anchored eyes positioned ^ ^ ^ run function nep:weapons/weapons/cousins/connroc/volley/nested_execute_0
