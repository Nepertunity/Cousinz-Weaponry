tag @s add temp
execute as @a if score @s lib.ID = @n[tag=temp] lib.ID run tag @s add temp_damage
scoreboard players add @s nep.timer 1
execute if score @s nep.timer matches 0 unless score @s nep.bool matches 1 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_15
execute if score @s nep.timer matches 1 unless score @s nep.bool matches 1 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_31
execute if score @s nep.timer matches 2 unless score @s nep.bool matches 1 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_47
execute if score @s nep.timer matches 3 unless score @s nep.bool matches 1 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_63
execute if score @s nep.timer matches 4 unless score @s nep.bool matches 1 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_79
execute if score @s nep.timer matches 5 unless score @s nep.bool matches 1 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_95
execute if score @s nep.timer matches 6 unless score @s nep.bool matches 1 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_111
execute if score @s nep.timer matches 7 unless score @s nep.bool matches 1 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_127
execute if score @s nep.timer matches 8 unless score @s nep.bool matches 1 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_143
execute if score @s nep.timer matches 9 unless score @s nep.bool matches 1 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_159
execute if score @s nep.timer matches 10 unless score @s nep.bool matches 1 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_175
execute if score @s nep.timer matches 11 unless score @s nep.bool matches 1 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_191
execute if score @s nep.timer matches 12 unless score @s nep.bool matches 1 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_207
execute if score @s nep.timer matches 13 unless score @s nep.bool matches 1 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_223
execute if score @s nep.timer matches 14 unless score @s nep.bool matches 1 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_239
tag @p[tag=temp_damage] remove temp_damage
tag @s remove temp
