particle trial_omen ^ ^ ^
execute unless block ^ ^ ^0.1 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^0.1 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^0.1 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^0.2 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^0.2 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^0.2 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^0.30000000000000004 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^0.30000000000000004 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^0.30000000000000004 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^0.4 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^0.4 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^0.4 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^0.5 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^0.5 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^0.5 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^0.6 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^0.6 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^0.6 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^0.7 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^0.7 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^0.7 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^0.7999999999999999 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^0.7999999999999999 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^0.7999999999999999 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^0.8999999999999999 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^0.8999999999999999 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^0.8999999999999999 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^0.9999999999999999 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^0.9999999999999999 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^0.9999999999999999 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^1.0999999999999999 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^1.0999999999999999 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^1.0999999999999999 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^1.2 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^1.2 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^1.2 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^1.3 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^1.3 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^1.3 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^1.4000000000000001 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^1.4000000000000001 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^1.4000000000000001 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
execute unless block ^ ^ ^1.5000000000000002 #nep:raycast_pass run scoreboard players set @s nep.bool 1
execute positioned ^ ^ ^1.5000000000000002 run particle minecraft:ominous_spawning
execute positioned ^ ^ ^1.5000000000000002 as @e[distance=..2, tag=!temp_damage, type=!item] run damage @s 15 arrow by @p[tag=temp_damage]
