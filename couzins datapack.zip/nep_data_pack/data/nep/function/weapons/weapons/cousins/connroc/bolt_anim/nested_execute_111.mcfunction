particle trial_omen ^ ^ ^8.999999999999984
execute positioned ^ ^ ^9.099999999999984 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_96
execute positioned ^ ^ ^9.199999999999983 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_97
execute positioned ^ ^ ^9.299999999999983 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_98
execute positioned ^ ^ ^9.399999999999983 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_99
execute positioned ^ ^ ^9.499999999999982 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_100
execute positioned ^ ^ ^9.599999999999982 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_101
execute positioned ^ ^ ^9.699999999999982 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_102
execute positioned ^ ^ ^9.799999999999981 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_103
execute positioned ^ ^ ^9.89999999999998 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_104
execute positioned ^ ^ ^9.99999999999998 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_105
execute positioned ^ ^ ^10.09999999999998 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_106
execute positioned ^ ^ ^10.19999999999998 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_107
execute positioned ^ ^ ^10.29999999999998 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_108
execute positioned ^ ^ ^10.399999999999979 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_109
execute positioned ^ ^ ^10.499999999999979 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_110
