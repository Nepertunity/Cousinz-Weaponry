particle trial_omen ^ ^ ^14.999999999999963
execute positioned ^ ^ ^15.099999999999962 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_160
execute positioned ^ ^ ^15.199999999999962 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_161
execute positioned ^ ^ ^15.299999999999962 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_162
execute positioned ^ ^ ^15.399999999999961 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_163
execute positioned ^ ^ ^15.499999999999961 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_164
execute positioned ^ ^ ^15.59999999999996 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_165
execute positioned ^ ^ ^15.69999999999996 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_166
execute positioned ^ ^ ^15.79999999999996 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_167
execute positioned ^ ^ ^15.89999999999996 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_168
execute positioned ^ ^ ^15.99999999999996 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_169
execute positioned ^ ^ ^16.09999999999996 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_170
execute positioned ^ ^ ^16.19999999999996 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_171
execute positioned ^ ^ ^16.29999999999996 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_172
execute positioned ^ ^ ^16.399999999999963 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_173
execute positioned ^ ^ ^16.499999999999964 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_174
