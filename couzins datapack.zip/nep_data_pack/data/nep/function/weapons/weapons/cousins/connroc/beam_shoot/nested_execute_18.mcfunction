execute positioned ^-0.04870883074715857 ^ ^0.1939779621690172 as @e[tag=!raycasting, dx=0] positioned ~-0.7 ~-0.7 ~-0.7 if entity @s[dx=0] positioned ~0.7 ~0.7 ~0.7 run function nep:weapons/weapons/cousins/connroc/beam_collide
execute positioned ^0.04870883074715857 ^ ^-0.1939779621690172 as @e[tag=!raycasting, dx=0] positioned ~-0.7 ~-0.7 ~-0.7 if entity @s[dx=0] positioned ~0.7 ~0.7 ~0.7 run function nep:weapons/weapons/cousins/connroc/beam_collide
particle minecraft:ominous_spawning ^-0.04870883074715857 ^ ^0.1939779621690172
particle minecraft:ominous_spawning ^0.04870883074715857 ^ ^-0.1939779621690172
execute unless block ~ ~ ~ #nep:raycast_pass run scoreboard players set rayHit nep.bool 1
