particle trial_omen ^ ^ ^4.5
execute positioned ^ ^ ^4.6 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_48
execute positioned ^ ^ ^4.699999999999999 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_49
execute positioned ^ ^ ^4.799999999999999 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_50
execute positioned ^ ^ ^4.899999999999999 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_51
execute positioned ^ ^ ^4.999999999999998 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_52
execute positioned ^ ^ ^5.099999999999998 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_53
execute positioned ^ ^ ^5.1999999999999975 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_54
execute positioned ^ ^ ^5.299999999999997 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_55
execute positioned ^ ^ ^5.399999999999997 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_56
execute positioned ^ ^ ^5.4999999999999964 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_57
execute positioned ^ ^ ^5.599999999999996 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_58
execute positioned ^ ^ ^5.699999999999996 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_59
execute positioned ^ ^ ^5.799999999999995 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_60
execute positioned ^ ^ ^5.899999999999995 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_61
execute positioned ^ ^ ^5.999999999999995 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_62
