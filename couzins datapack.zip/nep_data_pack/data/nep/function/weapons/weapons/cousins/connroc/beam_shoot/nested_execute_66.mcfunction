execute positioned ^-0.13561350396891172 ^ ^-0.14699992360975553 as @e[tag=!raycasting, dx=0] positioned ~-0.7 ~-0.7 ~-0.7 if entity @s[dx=0] positioned ~0.7 ~0.7 ~0.7 run function nep:weapons/weapons/cousins/connroc/beam_collide
execute positioned ^0.13561350396891172 ^ ^0.14699992360975553 as @e[tag=!raycasting, dx=0] positioned ~-0.7 ~-0.7 ~-0.7 if entity @s[dx=0] positioned ~0.7 ~0.7 ~0.7 run function nep:weapons/weapons/cousins/connroc/beam_collide
particle minecraft:ominous_spawning ^-0.13561350396891172 ^ ^-0.14699992360975553
particle minecraft:ominous_spawning ^0.13561350396891172 ^ ^0.14699992360975553
execute unless block ~ ~ ~ #nep:raycast_pass run scoreboard players set rayHit nep.bool 1
