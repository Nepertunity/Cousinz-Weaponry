playsound minecraft:entity.copper_golem.spawn ambient @a
tag @s add shooter
execute anchored eyes positioned ^ ^ ^ summon marker run tag @s add nep.arcane_bow.shootersp
execute as @n[tag=nep.arcane_bow.shootersp] at @s store result entity @s Rotation[0] float 0.01 run data get entity @p[tag=shooter] Rotation[0] 100
execute as @n[tag=nep.arcane_bow.shootersp] at @s store result entity @s Rotation[1] float 0.01 run data get entity @p[tag=shooter] Rotation[1] 100
playsound minecraft:entity.breeze.jump ambient @a
execute store result score @n[tag=nep.arcane_bow.shootersp] lib.ID run scoreboard players get @s lib.ID
tag @e[tag=nep.arcane_bow.shootersp] add nep.arcane_bow.shooter
tag @e[tag=nep.arcane_bow.shootersp] remove nep.arcane_bow.shootersp
tag @s remove shooter
scoreboard players reset @s nep.arcane_bow.bolt
