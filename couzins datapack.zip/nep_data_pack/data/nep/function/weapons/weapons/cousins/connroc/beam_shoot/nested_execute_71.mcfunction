execute positioned ^0.19662125235249062 ^ ^0.0366071457961176 as @e[tag=!raycasting, dx=0] positioned ~-0.7 ~-0.7 ~-0.7 if entity @s[dx=0] positioned ~0.7 ~0.7 ~0.7 run function nep:weapons/weapons/cousins/connroc/beam_collide
execute positioned ^-0.19662125235249062 ^ ^-0.0366071457961176 as @e[tag=!raycasting, dx=0] positioned ~-0.7 ~-0.7 ~-0.7 if entity @s[dx=0] positioned ~0.7 ~0.7 ~0.7 run function nep:weapons/weapons/cousins/connroc/beam_collide
particle minecraft:ominous_spawning ^0.19662125235249062 ^ ^0.0366071457961176
particle minecraft:ominous_spawning ^-0.19662125235249062 ^ ^-0.0366071457961176
execute unless block ~ ~ ~ #nep:raycast_pass run scoreboard players set rayHit nep.bool 1
