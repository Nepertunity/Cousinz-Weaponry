particle trial_omen ^ ^ ^13.499999999999968
execute positioned ^ ^ ^13.599999999999968 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_144
execute positioned ^ ^ ^13.699999999999967 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_145
execute positioned ^ ^ ^13.799999999999967 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_146
execute positioned ^ ^ ^13.899999999999967 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_147
execute positioned ^ ^ ^13.999999999999966 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_148
execute positioned ^ ^ ^14.099999999999966 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_149
execute positioned ^ ^ ^14.199999999999966 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_150
execute positioned ^ ^ ^14.299999999999965 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_151
execute positioned ^ ^ ^14.399999999999965 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_152
execute positioned ^ ^ ^14.499999999999964 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_153
execute positioned ^ ^ ^14.599999999999964 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_154
execute positioned ^ ^ ^14.699999999999964 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_155
execute positioned ^ ^ ^14.799999999999963 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_156
execute positioned ^ ^ ^14.899999999999963 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_157
execute positioned ^ ^ ^14.999999999999963 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_158
