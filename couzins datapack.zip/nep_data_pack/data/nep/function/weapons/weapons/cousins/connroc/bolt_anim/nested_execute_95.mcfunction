particle trial_omen ^ ^ ^7.499999999999989
execute positioned ^ ^ ^7.599999999999989 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_80
execute positioned ^ ^ ^7.699999999999989 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_81
execute positioned ^ ^ ^7.799999999999988 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_82
execute positioned ^ ^ ^7.899999999999988 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_83
execute positioned ^ ^ ^7.999999999999988 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_84
execute positioned ^ ^ ^8.099999999999987 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_85
execute positioned ^ ^ ^8.199999999999987 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_86
execute positioned ^ ^ ^8.299999999999986 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_87
execute positioned ^ ^ ^8.399999999999986 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_88
execute positioned ^ ^ ^8.499999999999986 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_89
execute positioned ^ ^ ^8.599999999999985 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_90
execute positioned ^ ^ ^8.699999999999985 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_91
execute positioned ^ ^ ^8.799999999999985 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_92
execute positioned ^ ^ ^8.899999999999984 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_93
execute positioned ^ ^ ^8.999999999999984 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_94
