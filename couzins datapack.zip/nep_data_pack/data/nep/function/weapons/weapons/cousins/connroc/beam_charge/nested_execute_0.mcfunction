function nep:weapons/weapons/cousins/connroc/beam_shoot
playsound minecraft:entity.allay.hurt ambient @a
scoreboard players reset @s nep.arcane_bow.beam
