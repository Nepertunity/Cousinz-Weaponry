scoreboard players set rayHit nep.bool 1
damage @s[type=!item] 25 arrow by @n[tag=raycasting]
