particle trial_omen ^ ^ ^5.999999999999995
execute positioned ^ ^ ^6.099999999999994 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_64
execute positioned ^ ^ ^6.199999999999994 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_65
execute positioned ^ ^ ^6.299999999999994 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_66
execute positioned ^ ^ ^6.399999999999993 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_67
execute positioned ^ ^ ^6.499999999999993 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_68
execute positioned ^ ^ ^6.5999999999999925 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_69
execute positioned ^ ^ ^6.699999999999992 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_70
execute positioned ^ ^ ^6.799999999999992 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_71
execute positioned ^ ^ ^6.8999999999999915 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_72
execute positioned ^ ^ ^6.999999999999991 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_73
execute positioned ^ ^ ^7.099999999999991 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_74
execute positioned ^ ^ ^7.19999999999999 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_75
execute positioned ^ ^ ^7.29999999999999 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_76
execute positioned ^ ^ ^7.39999999999999 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_77
execute positioned ^ ^ ^7.499999999999989 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_78
