tag @s add raycast
tag @s add raycasting
execute at @s anchored eyes run function nep:weapons/weapons/cousins/connroc/beam_shoot/nested_execute_100
tag @s remove raycasting
scoreboard players reset rayHit nep.bool
tag @s remove raycast
