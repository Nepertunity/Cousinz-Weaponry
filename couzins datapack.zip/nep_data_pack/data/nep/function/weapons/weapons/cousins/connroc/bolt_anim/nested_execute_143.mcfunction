particle trial_omen ^ ^ ^11.999999999999973
execute positioned ^ ^ ^12.099999999999973 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_128
execute positioned ^ ^ ^12.199999999999973 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_129
execute positioned ^ ^ ^12.299999999999972 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_130
execute positioned ^ ^ ^12.399999999999972 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_131
execute positioned ^ ^ ^12.499999999999972 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_132
execute positioned ^ ^ ^12.599999999999971 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_133
execute positioned ^ ^ ^12.69999999999997 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_134
execute positioned ^ ^ ^12.79999999999997 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_135
execute positioned ^ ^ ^12.89999999999997 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_136
execute positioned ^ ^ ^12.99999999999997 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_137
execute positioned ^ ^ ^13.09999999999997 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_138
execute positioned ^ ^ ^13.199999999999969 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_139
execute positioned ^ ^ ^13.299999999999969 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_140
execute positioned ^ ^ ^13.399999999999968 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_141
execute positioned ^ ^ ^13.499999999999968 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_142
