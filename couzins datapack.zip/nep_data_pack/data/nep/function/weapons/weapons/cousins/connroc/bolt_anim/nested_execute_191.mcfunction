particle trial_omen ^ ^ ^16.499999999999964
execute positioned ^ ^ ^16.599999999999966 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_176
execute positioned ^ ^ ^16.699999999999967 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_177
execute positioned ^ ^ ^16.79999999999997 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_178
execute positioned ^ ^ ^16.89999999999997 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_179
execute positioned ^ ^ ^16.99999999999997 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_180
execute positioned ^ ^ ^17.099999999999973 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_181
execute positioned ^ ^ ^17.199999999999974 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_182
execute positioned ^ ^ ^17.299999999999976 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_183
execute positioned ^ ^ ^17.399999999999977 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_184
execute positioned ^ ^ ^17.49999999999998 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_185
execute positioned ^ ^ ^17.59999999999998 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_186
execute positioned ^ ^ ^17.69999999999998 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_187
execute positioned ^ ^ ^17.799999999999983 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_188
execute positioned ^ ^ ^17.899999999999984 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_189
execute positioned ^ ^ ^17.999999999999986 run function nep:weapons/weapons/cousins/connroc/bolt_anim/nested_execute_190
