execute positioned ^0.19604852816202165 ^ ^-0.03955975992729246 as @e[tag=!raycasting, dx=0] positioned ~-0.7 ~-0.7 ~-0.7 if entity @s[dx=0] positioned ~0.7 ~0.7 ~0.7 run function nep:weapons/weapons/cousins/connroc/beam_collide
execute positioned ^-0.19604852816202165 ^ ^0.03955975992729246 as @e[tag=!raycasting, dx=0] positioned ~-0.7 ~-0.7 ~-0.7 if entity @s[dx=0] positioned ~0.7 ~0.7 ~0.7 run function nep:weapons/weapons/cousins/connroc/beam_collide
particle minecraft:ominous_spawning ^0.19604852816202165 ^ ^-0.03955975992729246
particle minecraft:ominous_spawning ^-0.19604852816202165 ^ ^0.03955975992729246
execute unless block ~ ~ ~ #nep:raycast_pass run scoreboard players set rayHit nep.bool 1
