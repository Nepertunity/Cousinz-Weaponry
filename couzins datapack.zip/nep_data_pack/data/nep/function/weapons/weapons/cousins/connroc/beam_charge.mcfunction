scoreboard players add @s nep.arcane_bow.beam 1
execute if score @s nep.arcane_bow.beam matches 0 run playsound minecraft:block.note_block.harp ambient @s ~ ~ ~ 1 0.0
execute if score @s nep.arcane_bow.beam matches 1 run playsound minecraft:block.note_block.harp ambient @s ~ ~ ~ 1 0.08
execute if score @s nep.arcane_bow.beam matches 2 run playsound minecraft:block.note_block.harp ambient @s ~ ~ ~ 1 0.16
execute if score @s nep.arcane_bow.beam matches 3 run playsound minecraft:block.note_block.harp ambient @s ~ ~ ~ 1 0.24
execute if score @s nep.arcane_bow.beam matches 4 run playsound minecraft:block.note_block.harp ambient @s ~ ~ ~ 1 0.32
execute if score @s nep.arcane_bow.beam matches 5 run playsound minecraft:block.note_block.harp ambient @s ~ ~ ~ 1 0.4
execute if score @s nep.arcane_bow.beam matches 6 run playsound minecraft:block.note_block.harp ambient @s ~ ~ ~ 1 0.48
execute if score @s nep.arcane_bow.beam matches 7 run playsound minecraft:block.note_block.harp ambient @s ~ ~ ~ 1 0.56
execute if score @s nep.arcane_bow.beam matches 8 run playsound minecraft:block.note_block.harp ambient @s ~ ~ ~ 1 0.64
execute if score @s nep.arcane_bow.beam matches 9 run playsound minecraft:block.note_block.harp ambient @s ~ ~ ~ 1 0.72
execute if score @s nep.arcane_bow.beam matches 10 run playsound minecraft:block.note_block.harp ambient @s ~ ~ ~ 1 0.8
execute if score @s nep.arcane_bow.beam matches 11 run playsound minecraft:block.note_block.harp ambient @s ~ ~ ~ 1 0.88
execute if score @s nep.arcane_bow.beam matches 12 run playsound minecraft:block.note_block.harp ambient @s ~ ~ ~ 1 0.96
execute if score @s nep.arcane_bow.beam matches 13 run playsound minecraft:block.note_block.harp ambient @s ~ ~ ~ 1 1.04
execute if score @s nep.arcane_bow.beam matches 14 run playsound minecraft:block.note_block.harp ambient @s ~ ~ ~ 1 1.12
execute if score @s nep.arcane_bow.beam matches 15 run playsound minecraft:block.note_block.harp ambient @s ~ ~ ~ 1 1.2
execute if score @s nep.arcane_bow.beam matches 16 run playsound minecraft:block.note_block.harp ambient @s ~ ~ ~ 1 1.28
execute if score @s nep.arcane_bow.beam matches 17 run playsound minecraft:block.note_block.harp ambient @s ~ ~ ~ 1 1.36
execute if score @s nep.arcane_bow.beam matches 18 run playsound minecraft:block.note_block.harp ambient @s ~ ~ ~ 1 1.44
execute if score @s nep.arcane_bow.beam matches 19 run playsound minecraft:block.note_block.harp ambient @s ~ ~ ~ 1 1.52
execute if score @s nep.arcane_bow.beam matches 20 run playsound minecraft:block.note_block.harp ambient @s ~ ~ ~ 1 1.6
execute if score @s nep.arcane_bow.beam matches 21 run playsound minecraft:block.note_block.harp ambient @s ~ ~ ~ 1 1.68
execute if score @s nep.arcane_bow.beam matches 22 run playsound minecraft:block.note_block.harp ambient @s ~ ~ ~ 1 1.76
execute if score @s nep.arcane_bow.beam matches 23 run playsound minecraft:block.note_block.harp ambient @s ~ ~ ~ 1 1.84
execute if score @s nep.arcane_bow.beam matches 24 run playsound minecraft:block.note_block.harp ambient @s ~ ~ ~ 1 1.92
execute if score @s nep.arcane_bow.beam matches 25.. run function nep:weapons/weapons/cousins/connroc/beam_charge/nested_execute_0
