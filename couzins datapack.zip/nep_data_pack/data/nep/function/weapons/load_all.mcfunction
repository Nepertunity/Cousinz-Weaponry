function nep:weapons/load/arcane_bow
function nep:weapons/load/truncheon
function nep:weapons/load/spyglass_sniper
function nep:weapons/load/wardent
function nep:weapons/load/verdigris
function nep:weapons/load/dragon_ballista
function nep:weapons/load/magnite
