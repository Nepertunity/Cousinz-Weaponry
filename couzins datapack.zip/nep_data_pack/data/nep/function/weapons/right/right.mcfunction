function nep:weapons/right/arcane_bow/right
function nep:weapons/right/truncheon/right
function nep:weapons/right/spyglass_sniper/right
function nep:weapons/right/wardent/right
function nep:weapons/right/verdigris/right
function nep:weapons/right/dragon_ballista/right
function nep:weapons/right/magnite/right
