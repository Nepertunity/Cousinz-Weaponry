execute if items entity @s weapon.mainhand *[minecraft:custom_model_data={"strings":["spyglass_sniper"]}] run function nep:abilities/right/spyglass_sniper_r
