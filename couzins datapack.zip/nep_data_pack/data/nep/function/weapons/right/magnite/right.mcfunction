execute if items entity @s weapon.mainhand *[minecraft:custom_model_data={"strings":["magnite"]}] run function nep:abilities/right/magnite_r
