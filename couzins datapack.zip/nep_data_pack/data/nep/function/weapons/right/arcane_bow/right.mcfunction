execute if items entity @s weapon.mainhand *[minecraft:custom_model_data={"strings":["arcane_bow"]}] run function nep:abilities/right/arcane_bow_r
