function nep:weapons/weapons/cousins/nepertunity/aura_load
