function nep:weapons/tick/arcane_bow
function nep:weapons/tick/truncheon
function nep:weapons/tick/spyglass_sniper
function nep:weapons/tick/wardent
function nep:weapons/tick/verdigris
function nep:weapons/tick/dragon_ballista
function nep:weapons/tick/magnite
