execute as @a if items entity @s weapon.mainhand *[minecraft:custom_model_data={"strings":["wardent"]}] run function nep:weapons/tick/wardent/nested_execute_0
execute as @a unless items entity @s weapon.mainhand *[minecraft:custom_model_data={"strings":["wardent"]}] run tag @s remove nep.wardent
