execute as @a if items entity @s weapon.mainhand *[minecraft:custom_model_data={"strings":["truncheon"]}] run tag @s add nep.truncheon
execute as @a unless items entity @s weapon.mainhand *[minecraft:custom_model_data={"strings":["truncheon"]}] run tag @s remove nep.truncheon
