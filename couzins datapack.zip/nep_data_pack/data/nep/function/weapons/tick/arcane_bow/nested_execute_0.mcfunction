tag @s add nep.arcane_bow
execute if score @s nep.bow matches 1.. at @s anchored eyes positioned ^ ^ ^ run kill @n[type=arrow]
