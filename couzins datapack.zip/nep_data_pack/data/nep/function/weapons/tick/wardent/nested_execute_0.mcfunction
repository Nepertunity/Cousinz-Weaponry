tag @s add nep.wardent
execute at @s anchored eyes positioned ^ ^ ^-1 rotated as @s rotated ~ ~-90 run function nep:weapons/weapons/cousins/nepertunity/aura_tick
