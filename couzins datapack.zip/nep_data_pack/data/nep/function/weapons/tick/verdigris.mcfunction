execute as @a if items entity @s weapon.mainhand *[minecraft:custom_model_data={"strings":["verdigris"]}] run tag @s add nep.verdigris
execute as @a unless items entity @s weapon.mainhand *[minecraft:custom_model_data={"strings":["verdigris"]}] run tag @s remove nep.verdigris
