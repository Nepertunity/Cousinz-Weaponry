execute as @a if items entity @s weapon.mainhand *[minecraft:custom_model_data={"strings":["magnite"]}] run tag @s add nep.magnite
execute as @a unless items entity @s weapon.mainhand *[minecraft:custom_model_data={"strings":["magnite"]}] run tag @s remove nep.magnite
