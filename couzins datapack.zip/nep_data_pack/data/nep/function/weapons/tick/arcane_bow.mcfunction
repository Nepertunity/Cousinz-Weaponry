execute as @a if items entity @s weapon.mainhand *[minecraft:custom_model_data={"strings":["arcane_bow"]}] run function nep:weapons/tick/arcane_bow/nested_execute_0
execute as @a unless items entity @s weapon.mainhand *[minecraft:custom_model_data={"strings":["arcane_bow"]}] run tag @s remove nep.arcane_bow
