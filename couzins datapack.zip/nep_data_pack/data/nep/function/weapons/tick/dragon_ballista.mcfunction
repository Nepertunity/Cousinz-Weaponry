execute as @a if items entity @s weapon.mainhand *[minecraft:custom_model_data={"strings":["dragon_ballista"]}] run tag @s add nep.dballista
execute as @a unless items entity @s weapon.mainhand *[minecraft:custom_model_data={"strings":["dragon_ballista"]}] run tag @s remove nep.dballista
