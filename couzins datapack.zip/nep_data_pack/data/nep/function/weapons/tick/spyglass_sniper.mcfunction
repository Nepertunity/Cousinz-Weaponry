execute as @a if items entity @s weapon.mainhand *[minecraft:custom_model_data={"strings":["spyglass_sniper"]}] run tag @s add nep.spyglass_sniper
execute as @a unless items entity @s weapon.mainhand *[minecraft:custom_model_data={"strings":["spyglass_sniper"]}] run tag @s remove nep.spyglass_sniper
