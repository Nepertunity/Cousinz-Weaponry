function nep:weapons/left/arcane_bow/left
function nep:weapons/left/truncheon/left
function nep:weapons/left/spyglass_sniper/left
function nep:weapons/left/wardent/left
function nep:weapons/left/verdigris/left
function nep:weapons/left/dragon_ballista/left
function nep:weapons/left/magnite/left
