execute if items entity @s weapon.mainhand *[minecraft:custom_model_data={"strings":["dragon_ballista"]}] run function nep:abilities/left/dragon_ballista_l
