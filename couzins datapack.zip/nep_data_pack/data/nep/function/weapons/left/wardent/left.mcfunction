execute if items entity @s weapon.mainhand *[minecraft:custom_model_data={"strings":["wardent"]}] run function nep:abilities/left/wardent_l
