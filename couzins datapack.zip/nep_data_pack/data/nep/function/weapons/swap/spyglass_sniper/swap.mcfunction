execute if items entity @s weapon.mainhand *[minecraft:custom_model_data={"strings":["spyglass_sniper"]}] run function nep:abilities/swap/spyglass_sniper_sw
