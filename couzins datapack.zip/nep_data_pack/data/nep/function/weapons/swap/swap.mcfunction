function nep:weapons/swap/arcane_bow/swap
function nep:weapons/swap/truncheon/swap
function nep:weapons/swap/spyglass_sniper/swap
function nep:weapons/swap/wardent/swap
function nep:weapons/swap/verdigris/swap
function nep:weapons/swap/dragon_ballista/swap
function nep:weapons/swap/magnite/swap
