execute if items entity @s weapon.mainhand *[minecraft:custom_model_data={"strings":["truncheon"]}] run function nep:abilities/swap/truncheon_sw
