execute if items entity @s weapon.mainhand *[minecraft:custom_model_data={"strings":["wardent"]}] run function nep:abilities/swap/wardent_sw
