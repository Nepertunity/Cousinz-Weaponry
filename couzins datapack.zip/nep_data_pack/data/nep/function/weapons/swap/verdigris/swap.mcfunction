execute if items entity @s weapon.mainhand *[minecraft:custom_model_data={"strings":["verdigris"]}] run function nep:abilities/swap/verdigris_sw
