execute if items entity @s weapon.mainhand *[minecraft:custom_model_data={"strings":["dragon_ballista"]}] run function nep:abilities/swap/dragon_ballista_sw
