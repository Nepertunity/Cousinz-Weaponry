execute if score @s nep.arcane_bow.bolt matches 20.. unless predicate nep:is_sneaking run function nep:weapons/weapons/cousins/connroc/bolt
execute if predicate nep:is_sneaking run function nep:weapons/weapons/cousins/connroc/beam_charge
