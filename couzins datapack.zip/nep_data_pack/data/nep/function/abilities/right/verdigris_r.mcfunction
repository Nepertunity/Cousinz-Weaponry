execute if score @s nep.verdigris.spawn.cd matches 35.. if predicate nep:is_sneaking run function nep:weapons/weapons/cousins/prince_josh/turret_summon_raycast
execute if score @s nep.verdigris.grapple matches 20.. unless predicate nep:is_sneaking run function nep:weapons/weapons/cousins/prince_josh/grapple
