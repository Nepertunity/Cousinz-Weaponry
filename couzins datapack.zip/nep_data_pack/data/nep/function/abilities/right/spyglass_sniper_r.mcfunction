execute if predicate nep:is_sneaking if score @s nep.spyglass_sniper.snipe_cd matches 15.. run function nep:weapons/weapons/cousins/foxttell11/snipe
