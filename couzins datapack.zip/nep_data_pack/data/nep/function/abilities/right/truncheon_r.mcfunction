execute if score @s nep.truncheon.launch.cd matches 10.. run function nep:weapons/weapons/cousins/connroc2/launch
