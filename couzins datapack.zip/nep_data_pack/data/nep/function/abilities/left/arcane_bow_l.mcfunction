execute if score @s nep.arcane_bow.volley matches 40.. run function nep:weapons/weapons/cousins/connroc/volley
