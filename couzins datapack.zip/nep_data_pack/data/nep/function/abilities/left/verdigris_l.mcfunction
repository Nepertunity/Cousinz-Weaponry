execute if score @s nep.verdigris.nugget.cd matches 10.. run function nep:weapons/weapons/cousins/prince_josh/nugget
