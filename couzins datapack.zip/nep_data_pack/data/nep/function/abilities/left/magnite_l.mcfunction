execute if score @s nep.magnite.cd matches 20.. at @s anchored eyes positioned ^ ^ ^ run function nep:weapons/weapons/cousins/tephlin/dripstone_raycast
