execute if score @s nep.dballista.escape.cd matches 10.. run function nep:weapons/weapons/cousins/renderdragons/escape
