execute if score @s nep.spyglass_sniper.launch_cd matches 15.. run function nep:weapons/weapons/cousins/foxttell11/lunge
