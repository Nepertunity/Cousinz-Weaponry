execute if score @s nep.wardent.cd matches 20.. run function nep:weapons/weapons/cousins/nepertunity/spout
