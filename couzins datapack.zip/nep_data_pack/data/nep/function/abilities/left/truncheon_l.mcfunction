execute if score @s nep.bmonk.spinatk matches 20.. run function nep:weapons/weapons/cousins/connroc2/ab
