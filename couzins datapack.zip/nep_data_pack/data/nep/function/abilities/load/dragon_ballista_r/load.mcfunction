scoreboard objectives add nep.dballista.bomb.marker dummy
