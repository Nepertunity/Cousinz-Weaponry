scoreboard objectives add nep.spyglass_sniper.launch_cd dummy
scoreboard objectives add nep.spyglass_sniper.snipe_cd dummy
scoreboard objectives add nep.spyglass_sniper.launching dummy
