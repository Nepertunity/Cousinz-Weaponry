scoreboard objectives add nep.arcane_bow.beam dummy
scoreboard objectives add nep.arcane_bow.bolt dummy
scoreboard objectives add nep.arcane_bow.volley dummy
