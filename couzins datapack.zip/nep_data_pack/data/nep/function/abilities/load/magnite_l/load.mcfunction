scoreboard objectives add nep.magnite.cd dummy
