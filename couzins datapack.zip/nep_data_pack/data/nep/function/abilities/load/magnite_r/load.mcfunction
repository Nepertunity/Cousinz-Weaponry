scoreboard objectives add nep.magnite.tornado dummy
scoreboard objectives add nep.magnite.tornado_push dummy
