scoreboard objectives add nep.wardent.cd dummy
