scoreboard objectives add nep.dballista.arrow_timer dummy
scoreboard objectives add nep.dballista.bomb_timer dummy
scoreboard objectives add nep.dballista.escape.cd dummy
