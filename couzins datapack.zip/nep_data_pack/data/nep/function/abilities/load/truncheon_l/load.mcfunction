scoreboard objectives add nep.truncheon.launch.cd dummy
scoreboard objectives add nep.truncheon.launching dummy
