execute unless predicate nep:is_sneaking run scoreboard players reset @s nep.arcane_bow.beam
scoreboard players add @s nep.arcane_bow.bolt 1
scoreboard players add @s nep.arcane_bow.volley 1
