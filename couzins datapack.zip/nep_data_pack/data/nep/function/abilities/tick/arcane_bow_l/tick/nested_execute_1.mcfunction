execute at @s rotated as @s run function nep:weapons/weapons/cousins/connroc/volley_anim
execute if score @s nep.timer matches 16.. run kill @s
