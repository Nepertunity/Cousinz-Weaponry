execute at @s run function nep:weapons/weapons/cousins/connroc/bolt_anim
execute if score @s nep.timer matches 16.. run kill @s
