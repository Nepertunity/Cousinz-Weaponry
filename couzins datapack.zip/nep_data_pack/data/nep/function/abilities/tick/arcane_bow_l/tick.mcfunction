execute as @a[tag=nep.arcane_bow] at @s run function nep:abilities/tick/arcane_bow_l/tick/nested_execute_0
kill @e[tag=nep.arcane_bow.shootersp]
execute as @e[type=marker, tag=nep.arcane_bow.shooter_r] run function nep:abilities/tick/arcane_bow_l/tick/nested_execute_1
execute as @e[type=marker, tag=nep.arcane_bow.shooter] run function nep:abilities/tick/arcane_bow_l/tick/nested_execute_2
