execute as @e[type=marker, tag=nep.wardent.shooter] run function nep:abilities/tick/wardent_l/tick/nested_execute_0
execute as @a[tag=nep.wardent] run scoreboard players add @s nep.wardent.cd 1
