execute at @s rotated as @s run function nep:weapons/weapons/cousins/nepertunity/spout_anim
execute if score @s nep.timer matches 16.. run kill @s
