execute as @a[tag=nep.verdigris] run function nep:abilities/tick/verdigris_l/tick/nested_execute_0
function nep:weapons/weapons/cousins/prince_josh/turret_tick
function nep:weapons/weapons/cousins/prince_josh/lightning_hit
function nep:weapons/weapons/cousins/prince_josh/nugget_holder
