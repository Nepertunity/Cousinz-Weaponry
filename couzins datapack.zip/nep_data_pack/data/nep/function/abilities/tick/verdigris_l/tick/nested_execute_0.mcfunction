scoreboard players add @s nep.verdigris.grapple 1
scoreboard players add @s nep.verdigris.spawn.cd 1
scoreboard players add @s nep.verdigris.nugget.cd 1
