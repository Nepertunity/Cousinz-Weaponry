execute as @a[tag=nep.dballista] run scoreboard players add @s nep.dballista.escape.cd 1
