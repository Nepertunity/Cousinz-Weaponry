data merge entity @s {teleport_duration: 25}
tag @s remove nep.verdigris.coil_spawn
