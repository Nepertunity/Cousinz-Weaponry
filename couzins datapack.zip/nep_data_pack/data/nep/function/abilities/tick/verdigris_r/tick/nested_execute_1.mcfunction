function nep:weapons/weapons/cousins/prince_josh/turret_raycast
scoreboard players reset @s nep.verdigris.coil_cd
playsound minecraft:entity.breeze.deflect ambient @a
playsound minecraft:entity.breeze.hurt ambient @a
