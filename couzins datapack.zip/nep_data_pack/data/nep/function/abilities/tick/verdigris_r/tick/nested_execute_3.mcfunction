execute as @s[tag=nep.verdigris.coil_head] run function nep:abilities/tick/verdigris_r/tick/nested_execute_2
execute at @s if entity @e[tag=nep.verdigris.copper, distance=..15] run tp @s ~ ~ ~ facing entity @n[tag=nep.verdigris.copper] feet
execute at @s unless entity @e[tag=nep.verdigris.copper, distance=..15] run tp @s ~ ~ ~ facing entity @p eyes
