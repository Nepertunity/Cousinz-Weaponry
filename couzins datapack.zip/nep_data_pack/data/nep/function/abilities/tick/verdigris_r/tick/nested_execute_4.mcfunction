execute if score @s nep.verdigris.coil_timer matches 300.. run kill @s
execute as @s[tag=nep.verdigris.coil_spawn] if score @s nep.verdigris.coil_spawn_timer matches 15.. run function nep:abilities/tick/verdigris_r/tick/nested_execute_0
execute as @s[type=block_display, nbt={Tags: ["nep.verdigris.coil", "nep.verdigris.coil_spawn"], block_state: {Name: "minecraft:blast_furnace"}}] at @s run particle minecraft:dust_plume ~ ~-1 ~ 1 0 1 0 10
execute as @s[tag=nep.verdigris.coil_turret, tag=!nep.verdigris.coil_spawn] run function nep:abilities/tick/verdigris_r/tick/nested_execute_3
