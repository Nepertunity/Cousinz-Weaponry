scoreboard players add @s nep.verdigris.coil_cd 1
execute at @s positioned ^ ^ ^1.3 run function nep:weapons/weapons/cousins/prince_josh/bomb_particles
execute if score @s nep.verdigris.coil_cd matches 40.. at @s if entity @e[tag=nep.verdigris.copper, distance=..15, tag=!nep.verdigris.lightning_hit] run function nep:abilities/tick/verdigris_r/tick/nested_execute_1
