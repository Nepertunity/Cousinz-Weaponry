scoreboard players add @e[tag=nep.verdigris.coil] nep.verdigris.coil_timer 1
scoreboard players add @e[tag=nep.verdigris.coil_spawn] nep.verdigris.coil_spawn_timer 1
execute as @e[tag=nep.verdigris.coil] run function nep:abilities/tick/verdigris_r/tick/nested_execute_4
