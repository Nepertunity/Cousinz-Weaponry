execute at @s rotated as @s run function nep:weapons/weapons/cousins/renderdragons/bomb_anim
execute if score @s nep.timer matches 40.. run kill @s
