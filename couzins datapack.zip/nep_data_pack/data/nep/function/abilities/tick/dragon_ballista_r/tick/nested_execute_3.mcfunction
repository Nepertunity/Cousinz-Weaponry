scoreboard players add @s nep.dballista.bomb.marker 1
execute at @s if score @s nep.dballista.bomb.marker matches ..10 run function nep:weapons/weapons/cousins/renderdragons/bomb_particles
execute at @s if score @s nep.dballista.bomb.marker matches 15.. run function nep:abilities/tick/dragon_ballista_r/tick/nested_execute_2
