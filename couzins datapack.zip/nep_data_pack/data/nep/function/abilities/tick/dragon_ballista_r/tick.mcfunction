execute as @a[tag=nep.dballista] if score @s nep.crossbow matches 1.. at @s run function nep:abilities/tick/dragon_ballista_r/tick/nested_execute_0
execute as @e[type=marker, tag=nep.dballista.shooter] run function nep:abilities/tick/dragon_ballista_r/tick/nested_execute_1
execute as @e[type=marker, tag=nep.dballista.bomb.marker] run function nep:abilities/tick/dragon_ballista_r/tick/nested_execute_3
