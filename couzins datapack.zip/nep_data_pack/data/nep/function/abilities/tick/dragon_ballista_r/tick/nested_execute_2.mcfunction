tag @s add nep.temp
function nep:weapons/weapons/cousins/renderdragons/bomb_particles2
playsound minecraft:block.trial_spawner.ominous_activate ambient @a
execute as @e[distance=..4.5] run damage @s[type=!item] 25 player_explosion by @n[tag=nep.temp]
kill @s
tag @s remove nep.temp
