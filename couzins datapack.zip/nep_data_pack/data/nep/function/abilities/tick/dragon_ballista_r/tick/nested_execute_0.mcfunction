execute anchored eyes positioned ^ ^ ^ run kill @n[type=arrow]
function nep:weapons/weapons/cousins/renderdragons/bomb
