scoreboard players reset @s nep.truncheon.launching
tag @s remove nep.truncheon.launching
