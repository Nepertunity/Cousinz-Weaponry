execute as @a[tag=nep.truncheon] run scoreboard players add @s nep.truncheon.launch.cd 1
execute as @a[tag=nep.truncheon.launching] run function nep:abilities/tick/truncheon_l/tick/nested_execute_1
