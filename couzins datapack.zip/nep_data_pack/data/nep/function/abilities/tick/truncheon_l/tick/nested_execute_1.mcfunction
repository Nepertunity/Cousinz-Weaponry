scoreboard players add @s nep.truncheon.launching 1
execute at @s run particle enchant
execute if score @s nep.truncheon.launching matches 20.. if predicate nep:is_on_ground run function nep:abilities/tick/truncheon_l/tick/nested_execute_0
