execute as @a[tag=nep.magnite] run scoreboard players add @s nep.magnite.cd 1
execute as @e[tag=nep.magnite.dripstone, type=block_display] run function nep:abilities/tick/magnite_l/tick/nested_execute_2
