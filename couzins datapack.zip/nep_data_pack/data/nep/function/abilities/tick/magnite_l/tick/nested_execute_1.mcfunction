execute as @e[distance=..2.25, type=!item] run function nep:abilities/tick/magnite_l/tick/nested_execute_0
particle poof ~ ~ ~ 1 1 1 0.1 20
particle minecraft:dust_plume ~ ~ ~ 1 0 1 0 200
