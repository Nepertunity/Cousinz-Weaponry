tag @s add temp
scoreboard players add @s nep.timer 1
execute at @s if score @s nep.timer matches ..15 run function nep:weapons/weapons/cousins/tephlin/dripstone_particles
execute at @s if score @s nep.timer matches 25 run function nep:abilities/tick/magnite_l/tick/nested_execute_1
execute if score @s nep.timer matches 35.. run kill @s
tag @s remove temp
