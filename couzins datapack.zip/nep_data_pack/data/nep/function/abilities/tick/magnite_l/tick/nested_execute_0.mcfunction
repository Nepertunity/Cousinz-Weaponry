damage @s 10 minecraft:falling_stalactite by @n[tag=temp, distance=..100]
effect give @s slowness 6 3
