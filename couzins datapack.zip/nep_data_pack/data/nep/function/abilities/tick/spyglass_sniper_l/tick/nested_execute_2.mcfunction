scoreboard players add @s nep.spyglass_sniper.launch_cd 1
scoreboard players add @s nep.spyglass_sniper.snipe_cd 1
execute as @s[tag=nep.spyglass_sniper.launch] run function nep:abilities/tick/spyglass_sniper_l/tick/nested_execute_1
