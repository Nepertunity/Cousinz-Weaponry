execute as @a[tag=nep.spyglass_sniper] run function nep:abilities/tick/spyglass_sniper_l/tick/nested_execute_2
