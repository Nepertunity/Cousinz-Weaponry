scoreboard players add @s nep.spyglass_sniper.launching 1
execute at @s run function nep:abilities/tick/spyglass_sniper_l/tick/nested_execute_0
execute if predicate nep:is_on_ground if score @s nep.spyglass_sniper.launching matches 5.. run tag @s remove nep.spyglass_sniper.launch
