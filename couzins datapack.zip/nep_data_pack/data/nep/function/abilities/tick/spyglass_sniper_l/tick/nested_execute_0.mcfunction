particle ominous_spawning ^-1 ^ ^
particle ominous_spawning ^1 ^ ^
