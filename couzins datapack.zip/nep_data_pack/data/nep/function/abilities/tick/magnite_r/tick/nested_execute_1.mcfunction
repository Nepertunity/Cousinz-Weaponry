function nep:weapons/weapons/cousins/tephlin/tornado
tag @s add nep.magnite.bobber
execute at @s as @e[distance=..9, tag=!nep.magnite.bobber] run function nep:abilities/tick/magnite_r/tick/nested_execute_0
tag @s remove nep.magnite.bobber
