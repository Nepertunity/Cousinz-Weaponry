scoreboard players reset @s nep.magnite.tornado_push
execute as @s[type=!player] at @s anchored feet facing entity @n[tag=nep.magnite.bobber] feet run function nep:weapons/weapons/cousins/tephlin/mob_pull
