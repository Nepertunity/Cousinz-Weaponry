execute as @a[tag=nep.magnite] if score @s nep.fishing_rod matches 1.. anchored eyes positioned ^ ^ ^ run tag @n[type=fishing_bobber] add nep.magnite.tornado
execute as @e[type=fishing_bobber, tag=nep.magnite.tornado] at @s run function nep:abilities/tick/magnite_r/tick/nested_execute_2
