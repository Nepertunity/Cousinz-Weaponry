particle lava
execute as @s[nbt={OnGround: 1b}] run function nep:abilities/tick/magnite_r/tick/nested_execute_1
