scoreboard objectives add lib.ID dummy

scoreboard players add #maxid lib.ID 0
scoreboard players set #LIBID.active lib.ID 1

