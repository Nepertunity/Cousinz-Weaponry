scoreboard players add #maxid lib.ID 1
scoreboard players operation @s lib.ID = #maxid lib.ID