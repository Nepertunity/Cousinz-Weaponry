scoreboard objectives remove lib.ID
scoreboard objectives add lib.ID dummy
advancement revoke @a only lib:id_initialize
scoreboard players add #maxid lib.ID 0
scoreboard players set #LIBID.active lib.ID 1
say expirimental