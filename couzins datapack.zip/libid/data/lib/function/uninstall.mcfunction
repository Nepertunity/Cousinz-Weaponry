scoreboard objectives remove lib.ID
advancement revoke @a only lib:id_initialize
datapack disable "file/LibID"

