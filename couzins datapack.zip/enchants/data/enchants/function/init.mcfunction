# swap items
scoreboard objectives add success1 dummy
scoreboard objectives add success2 dummy
scoreboard objectives add success3 dummy

# general dummy
scoreboard objectives add uuid dummy


say loaded