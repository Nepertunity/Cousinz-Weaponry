execute store result score @s uuid run data get entity @s UUID[0]
tag @s add initialized