# check if i have main and offhand items.
execute store success score @s success1 run data get entity @s SelectedItem
execute store success score @s success2 run data get entity @s equipment.offhand

#execute store result score @s success1 if items entity @s weapon.mainhand *
#execute store result score @s success2 if items entity @s weapon.offhand *
##execute if score @s success1 matches 1.. run scoreboard players set @s success1 1
#execute if score @s success2 matches 1.. run scoreboard players set @s success2 1

# store uuid in storage for current player to use their storages for this loop
execute store result storage storage uuid int 1 run scoreboard players get @s uuid

#remove mainhand and offhand items if they don't exist
function enchants:chest/compare/macro/removeitems with storage storage

# if inventory changed, compare their items
execute if entity @s[tag=swapped] run function enchants:chest/compare/compare

# set storage to be correct values
function enchants:chest/compare/macro/modifyitems with storage storage

#cleanup
scoreboard players reset @s success1
scoreboard players reset @s success2