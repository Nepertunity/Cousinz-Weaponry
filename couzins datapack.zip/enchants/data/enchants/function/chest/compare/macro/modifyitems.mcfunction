$data modify storage storage:$(uuid) mainhand set from entity @s SelectedItem
$data modify storage storage:$(uuid) offhand set from entity @s equipment.offhand
$data remove storage storage:$(uuid) offhand.Slot