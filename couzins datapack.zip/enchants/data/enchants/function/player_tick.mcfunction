#function enchants:chest/compare/ontick
tag @s[tag=swapped] remove swapped
execute unless entity @s[tag=initialized] run function enchants:initialize

